TNSDC - IMPORT DATA USING TRANSFORM MAPS (SPREADSHEET)

Project:
Import Data Using Transform Maps (Spreadsheet)

Technology:
ServiceNow

Project Area:
Import Sets, Import Set Tables and Transform Maps

Workflow:
Spreadsheet -> Import Set Table -> Transform Map -> Target Employee Table -> Validation

Main Files:
- Project_Report.pdf
- Problem_Statement.pdf
- Project_Overview.docx
- README.txt

Sample Data Fields:
- Employee ID
- Name
- Email
- Department
- Location

Key Configuration:
Employee ID is used as the coalesce field when repeat imports are tested.

Evidence to capture:
- Source spreadsheet
- Import Set Table staged rows
- Transform Map
- Field Maps
- Transform History
- Target Table results
- Coalesce repeat-import result

Note:
The project uses synthetic demonstration data.
